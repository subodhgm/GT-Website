<?php
/**
 * Plugin Name: AI Autoblogger
 * Description: Lightweight, reliable AI-powered automated blog content generation.
 * Version: 1.0.0
 * Author: AI Agent
 * Text Domain: ai-autoblogger
 * Requires PHP: 7.4
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('AI_AUTOBLOGGER_VERSION', '1.0.0');
define('AI_AUTOBLOGGER_PATH', plugin_dir_path(__FILE__));
define('AI_AUTOBLOGGER_URL', plugin_dir_url(__FILE__));

// Load the main plugin class
require_once AI_AUTOBLOGGER_PATH . 'includes/class-plugin.php';

// Initialize the plugin
add_action('plugins_loaded', function() {
    AI_Autoblogger_Plugin::get_instance()->init();
});
