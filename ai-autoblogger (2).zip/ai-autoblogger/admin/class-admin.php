<?php
if (!defined('ABSPATH')) {
    exit;
}

class AI_Autoblogger_Admin {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_menu'));
    }

    public function add_menu() {
        add_menu_page(
            'AI Autoblogger',
            'AI Autoblogger',
            'manage_options',
            'ai-autoblogger',
            array($this, 'render_dashboard'),
            'dashicons-robot',
            25
        );

        add_submenu_page(
            'ai-autoblogger',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'ai-autoblogger',
            array($this, 'render_dashboard')
        );
        add_submenu_page(
            'ai-autoblogger',
            'Topics',
            'Topics',
            'manage_options',
            'ai-autoblogger-topics',
            array($this, 'render_topics')
        );
        add_submenu_page(
            'ai-autoblogger',
            'Settings',
            'Settings',
            'manage_options',
            'ai-autoblogger-settings',
            array($this, 'render_settings')
        );
        add_submenu_page(
            'ai-autoblogger',
            'Logs',
            'Logs',
            'manage_options',
            'ai-autoblogger-logs',
            array($this, 'render_logs')
        );
    }

    public function render_dashboard() {
        include AI_AUTOBLOGGER_PATH . 'admin/views/dashboard.php';
    }

    public function render_topics() {
        if (isset($_GET['action']) && $_GET['action'] === 'generate_now' && isset($_GET['topic_id'])) {
            if (!current_user_can('manage_options')) {
                wp_die('Unauthorized');
            }

            $topic_id = absint($_GET['topic_id']);
            $job_manager = AI_Autoblogger_Job_Manager::get_instance();
            
            // We use a separate method to process just one topic immediately
            $result = $job_manager->process_single_topic_now($topic_id);
            
            if ($result === true) {
                echo '<div class="notice notice-success is-dismissible"><p>Generation started for Topic ID ' . $topic_id . '. Check the logs for progress!</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Error: ' . $result . '</p></div>';
            }
        }

        include AI_AUTOBLOGGER_PATH . 'admin/views/topics.php';
    }

    public function render_settings() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Handle manual save to avoid options.php restriction
        if (isset($_POST['ai_autoblogger_save_settings']) && check_admin_referer('ai_autoblogger_save_action', 'ai_autoblogger_nonce')) {
            $this->handle_manual_save();
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
        }

        include AI_AUTOBLOGGER_PATH . 'admin/views/settings.php';
    }

    private function handle_manual_save() {
        $groups = array('general', 'provider_gemini', 'provider_ollama', 'content', 'automation');
        foreach ($groups as $group) {
            $option_name = "ai_autoblogger_{$group}";
            if (isset($_POST[$option_name]) && is_array($_POST[$option_name])) {
                $sanitized = array();
                foreach ($_POST[$option_name] as $key => $value) {
                    $sanitized[$key] = sanitize_text_field($value);
                }
                update_option($option_name, $sanitized);
            }
        }
        
        // Sync cron if automation settings changed
        AI_Autoblogger_Job_Manager::get_instance()->schedule_cron();
    }

    public function render_logs() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        include AI_AUTOBLOGGER_PATH . 'admin/views/logs.php';
    }
}
