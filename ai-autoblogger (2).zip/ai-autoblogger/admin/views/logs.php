<div class="wrap">
    <h1 class="wp-heading-inline">AI Autoblogger Activity Log</h1>
    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ai-autoblogger-logs&action=clear'), 'ai_autoblogger_clear_logs'); ?>" class="page-title-action" style="color: #d63638;">Clear Logs</a>
    <hr class="wp-header-end">

    <?php 
    if (isset($_GET['action']) && $_GET['action'] === 'clear') {
        if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'ai_autoblogger_clear_logs')) {
            AI_Autoblogger_Logger::get_instance()->clear_logs();
            echo '<div class="notice notice-success is-dismissible"><p>Logs cleared successfully.</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Security check failed. Please try again.</p></div>';
        }
    }

    $logs = AI_Autoblogger_Logger::get_instance()->get_logs();
    ?>

    <table class="widefat fixed striped">
        <thead>
            <tr>
                <th style="width: 180px;">Timestamp</th>
                <th style="width: 100px;">Level</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($logs): ?>
                <?php foreach ($logs as $log): 
                    $level_class = 'log-info';
                    switch ($log['level']) {
                        case 'SUCCESS': $level_class = 'log-success'; break;
                        case 'ERROR': $level_class = 'log-error'; break;
                        case 'WARNING': $level_class = 'log-warning'; break;
                    }
                ?>
                    <tr>
                        <td><?php echo esc_html($log['timestamp']); ?></td>
                        <td><span class="log-badge <?php echo $level_class; ?>"><?php echo esc_html($log['level']); ?></span></td>
                        <td><?php echo esc_html($log['message']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No activity logs found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
    .log-badge {
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 10px;
        font-weight: bold;
        color: #fff;
        text-transform: uppercase;
    }
    .log-info { background: #2271b1; }
    .log-success { background: #46b450; }
    .log-warning { background: #ffb900; color: #000; }
    .log-error { background: #d63638; }
</style>
