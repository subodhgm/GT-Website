<div class="wrap">
    <h1 class="wp-heading-inline">AI Autoblogger Topics</h1>
    <a href="<?php echo admin_url('post-new.php?post_type=ai_topic'); ?>" class="page-title-action">Add New Topic</a>
    <hr class="wp-header-end">

    <div class="notice notice-info">
        <p>Topics are stored as a custom post type. Use the <strong>Add New Topic</strong> button to add to the queue.</p>
    </div>

    <table class="widefat fixed striped">
        <thead>
            <tr>
                <th>Topic Title</th>
                <th>Primary Keyword</th>
                <th>Status</th>
                <th>Created Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $topic_manager = AI_Autoblogger_Topic_Manager::get_instance();
            $topics = get_posts(array(
                'post_type' => 'ai_topic',
                'posts_per_page' => -1,
                'orderby' => 'date',
                'order' => 'DESC'
            ));

            if ($topics): 
                foreach ($topics as $topic): 
                    $status = get_post_meta($topic->ID, '_ai_generation_status', true) ?: 'pending';
                    $keyword = get_post_meta($topic->ID, '_ai_primary_keyword', true);
            ?>
                <tr>
                    <td><strong><?php echo esc_html($topic->post_title); ?></strong></td>
                    <td><?php echo esc_html($keyword); ?></td>
                    <td>
                        <span class="status-badge status-<?php echo esc_attr($status); ?>">
                            <?php echo ucfirst(esc_html($status)); ?>
                        </span>
                    </td>
                    <td><?php echo esc_html($topic->post_date); ?></td>
                    <td>
                        <a href="<?php echo get_edit_post_link($topic->ID); ?>">Edit</a> 
                        <?php if ($status === 'pending' || $status === 'failed'): ?>
                            | <a href="<?php echo admin_url('admin.php?page=ai-autoblogger-topics&action=generate_now&topic_id=' . $topic->ID); ?>" style="color: #2271b1; font-weight: bold;">Generate Now</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php 
                endforeach; 
            else: 
            ?>
                <tr>
                    <td colspan="5">No topics found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
    .status-badge {
        padding: 3px 8px;
        border-radius: 3px;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
        color: #fff;
    }
    .status-pending { background: #bbb; }
    .status-processing { background: #ffb900; color: #000; }
    .status-completed { background: #46b450; }
    .status-failed { background: #dc3232; }
</style>
