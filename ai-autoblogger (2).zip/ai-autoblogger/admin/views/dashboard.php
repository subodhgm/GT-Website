<div class="wrap">
    <h1>AI Autoblogger Dashboard</h1>
    <div class="welcome-panel">
        <div class="welcome-panel-content">
            <p>Welcome to the AI Autoblogger. Manage your content generation and AI providers from here.</p>
            <table class="widefat fixed" style="max-width: 600px; margin-top: 20px;">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>AI Provider</strong></td>
                        <td><?php echo esc_html(AI_Autoblogger_Settings::get_instance()->get_group('general')['ai_provider'] ?? 'Not set'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Connection Status</strong></td>
                        <td><span class="dashicons dashicons-admin-generic">Checking...</span></td>
                    </tr>
                    <tr>
                        <td><strong>Pending Topics</strong></td>
                        <td>0</td>
                    </tr>
                    <tr>
                        <td><strong>Articles Generated</strong></td>
                        <td>0</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
