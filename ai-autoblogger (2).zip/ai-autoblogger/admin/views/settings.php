<div class="wrap">
    <h1>AI Autoblogger Settings</h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('ai_autoblogger_save_action', 'ai_autoblogger_nonce'); ?>
        
        <h2 class="nav-tab-wrapper">
            <a href="?page=ai-autoblogger-settings&tab=general" class="nav-tab <?php echo ($_GET['tab'] ?? 'general') === 'general' ? 'nav-tab-active' : ''; ?>">General</a>
            <a href="?page=ai-autoblogger-settings&tab=provider" class="nav-tab <?php echo ($_GET['tab'] ?? 'general') === 'provider' ? 'nav-tab-active' : ''; ?>">AI Provider</a>
            <a href="?page=ai-autoblogger-settings&tab=content" class="nav-tab <?php echo ($_GET['tab'] ?? 'general') === 'content' ? 'nav-tab-active' : ''; ?>">Content</a>
            <a href="?page=ai-autoblogger-settings&tab=automation" class="nav-tab <?php echo ($_GET['tab'] ?? 'general') === 'automation' ? 'nav-tab-active' : ''; ?>">Automation</a>
        </h2>

        <div class="settings-content" style="margin-top: 20px;">
            <?php 
            $tab = $_GET['tab'] ?? 'general';
            $settings = AI_Autoblogger_Settings::get_instance();
            
            if ($tab === 'general'): 
                $general = $settings->get_group('general');
            ?>
                <h3>General Settings</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">AI Provider</th>
                        <td>
                            <select name="ai_autoblogger_general[ai_provider]">
                                <option value="gemini" <?php selected($general['ai_provider'] ?? '', 'gemini'); ?>>Google Gemini</option>
                                <option value="ollama" <?php selected($general['ai_provider'] ?? '', 'ollama'); ?>>Local Ollama</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Default Post Status</th>
                        <td>
                            <select name="ai_autoblogger_general[post_status]">
                                <option value="draft" <?php selected($general['post_status'] ?? '', 'draft'); ?>>Draft</option>
                                <option value="pending" <?php selected($general['post_status'] ?? '', 'pending'); ?>>Pending Review</option>
                                <option value="publish" <?php selected($general['post_status'] ?? '', 'publish'); ?>>Published</option>
                                <option value="future" <?php selected($general['post_status'] ?? '', 'future'); ?>>Scheduled</option>
                            </select>
                        </td>
                    </tr>
                </table>
            <?php elseif ($tab === 'provider'): 
                $gemini = $settings->get_group('provider_gemini');
                $ollama = $settings->get_group('provider_ollama');
            ?>
                <h3>AI Provider Configuration</h3>
                <div style="background: #fff; padding: 15px; border: 1px solid #ccd0d4; margin-bottom: 20px;">
                    <h4>Google Gemini</h4>
                    <table class="form-table">
                        <tr>
                            <th scope="row">API Key</th>
                            <td><input type="password" name="ai_autoblogger_provider_gemini[api_key]" value="<?php echo esc_attr($gemini['api_key'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th scope="row">Model</th>
                            <td><input type="text" name="ai_autoblogger_provider_gemini[model]" value="<?php echo esc_attr($gemini['model'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                    </table>
                </div>
                <div style="background: #fff; padding: 15px; border: 1px solid #ccd0d4;">
                    <h4>Local Ollama</h4>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Endpoint</th>
                            <td><input type="text" name="ai_autoblogger_provider_ollama[endpoint]" value="<?php echo esc_attr($ollama['endpoint'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th scope="row">Model</th>
                            <td><input type="text" name="ai_autoblogger_provider_ollama[model]" value="<?php echo esc_attr($ollama['model'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                    </table>
                </div>
            <?php elseif ($tab === 'content'): 
                $content = $settings->get_group('content');
            ?>
                <h3>Content Generation Settings</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">Max Word Count</th>
                        <td><input type="number" name="ai_autoblogger_content[max_word_count]" value="<?php echo esc_attr($content['max_word_count'] ?? '2000'); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Language</th>
                        <td><input type="text" name="ai_autoblogger_content[language]" value="<?php echo esc_attr($content['language'] ?? 'English'); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Tone</th>
                        <td><input type="text" name="ai_autoblogger_content[tone]" value="<?php echo esc_attr($content['tone'] ?? 'Professional'); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">Writing Instructions</th>
                        <td><textarea name="ai_autoblogger_content[instructions]" rows="5" class="large-text"><?php echo esc_textarea($content['instructions'] ?? ''); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row">Article Type</th>
                        <td><input type="text" name="ai_autoblogger_content[article_type]" value="<?php echo esc_attr($content['article_type'] ?? 'Blog Article'); ?>"></td>
                    </tr>
                </table>
            <?php elseif ($tab === 'automation'): 
                $auto = $settings->get_group('automation');
            ?>
                <h3>Automation Settings</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable Automatic Generation</th>
                        <td>
                            <select name="ai_autoblogger_automation[enabled]">
                                <option value="yes" <?php selected($auto['enabled'] ?? '', 'yes'); ?>>Yes</option>
                                <option value="no" <?php selected($auto['enabled'] ?? '', 'no'); ?>>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Frequency</th>
                        <td>
                            <select name="ai_autoblogger_automation[frequency]">
                                <option value="hourly" <?php selected($auto['frequency'] ?? '', 'hourly'); ?>>Every Hour</option>
                                <option value="daily" <?php selected($auto['frequency'] ?? '', 'daily'); ?>>Every Day</option>
                                <option value="weekly" <?php selected($auto['frequency'] ?? '', 'weekly'); ?>>Every Week</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Articles Per Run</th>
                        <td><input type="number" name="ai_autoblogger_automation[articles_per_run]" value="<?php echo esc_attr($auto['articles_per_run'] ?? '1'); ?>"></td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>
        <input type="submit" name="ai_autoblogger_save_settings" class="button button-primary" value="Save Changes">
    </form>
</div>
