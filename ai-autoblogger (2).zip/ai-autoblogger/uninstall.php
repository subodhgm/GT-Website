<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Uninstall script to ensure no leftovers in database.
 */
$settings = AI_Autoblogger_Settings::get_instance();
$groups = array('general', 'provider_gemini', 'provider_ollama', 'content', 'automation');
foreach ($groups as $group) {
    delete_option("ai_autoblogger_{$group}");
}
delete_option('ai_autoblogger_logs');

// Note: we typically don't delete CPT posts (ai_topic) unless specifically requested,
// as users might want to keep their research/queue history.
