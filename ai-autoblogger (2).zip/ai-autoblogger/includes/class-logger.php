<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AI_Autoblogger_Logger
 * 
 * Provides a lightweight logging system to track AI generation activity.
 */
class AI_Autoblogger_Logger {
    private static $instance = null;
    private $option_name = 'ai_autoblogger_logs';
    private $max_logs = 100;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Add a log entry.
     * 
     * @param string $level 'INFO', 'SUCCESS', 'WARNING', 'ERROR'
     * @param string $message The log message.
     */
    public function log($level, $message) {
        $logs = get_option($this->option_name, array());

        $entry = array(
            'timestamp' => current_time('mysql'),
            'level'     => strtoupper($level),
            'message'   => $message,
        );

        array_unshift($logs, $entry);

        // Cap the logs to avoid bloating the options table
        if (count($logs) > $this->max_logs) {
            $logs = array_slice($logs, 0, $this->max_logs);
        }

        update_option($this->option_name, $logs);
    }

    public function get_logs() {
        return get_option($this->option_name, array());
    }

    public function clear_logs() {
        delete_option($this->option_name);
    }
}
