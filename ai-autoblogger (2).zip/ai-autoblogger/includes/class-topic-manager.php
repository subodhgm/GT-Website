<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AI_Autoblogger_Topic_Manager
 * 
 * Handles the management of blog topics using a Custom Post Type.
 */
class AI_Autoblogger_Topic_Manager {
    private static $instance = null;
    private $post_type = 'ai_topic';

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', array($this, 'register_post_type'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_topic_meta'));
    }

    /**
     * Register the ai_topic Custom Post Type.
     */
    public function register_post_type() {
        $labels = array(
            'name'               => 'AI Topics',
            'singular_name'      => 'AI Topic',
            'menu_name'          => 'AI Topics',
            'add_new'            => 'Add New Topic',
            'add_new_item'       => 'Add New Blog Topic',
            'edit_item'          => 'Edit Topic',
            'all_items'          => 'All Topics',
            'view_item'          => 'View Topic',
            'search_items'       => 'Search Topics',
            'not_found'          => 'No topics found',
            'not_found_in_trash' => 'No topics found in trash',
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'show_ui'            => true,
            'show_in_menu'       => false, // We use our own admin menu
            'capability_type'    => 'post',
            'hierarchical'       => false,
            'supports'           => array('title'),
            'has_archive'        => false,
            'rewrite'            => array('slug' => 'ai-topic'),
        );

        register_post_type($this->post_type, $args);
    }

    /**
     * Add meta boxes for keywords, categories, and status.
     */
    public function add_meta_boxes() {
        add_meta_box(
            'ai_topic_details',
            'Topic Details',
            array($this, 'render_meta_box'),
            $this->post_type,
            'normal',
            'high'
        );
    }

    public function render_meta_box($post) {
        wp_nonce_field('ai_topic_meta_save', 'ai_topic_meta_nonce');

        $primary_keyword = get_post_meta($post->ID, '_ai_primary_keyword', true);
        $secondary_keywords = get_post_meta($post->ID, '_ai_secondary_keywords', true);
        $category = get_post_meta($post->ID, '_ai_category', true);
        $status = get_post_meta($post->ID, '_ai_generation_status', true) ?: 'pending';
        $post_id = get_post_meta($post->ID, '_ai_generated_post_id', true);

        ?>
        <div class="ai-topic-meta-wrapper">
            <p>
                <label for="ai_primary_keyword"><strong>Primary Keyword:</strong></label><br>
                <input type="text" id="ai_primary_keyword" name="ai_primary_keyword" value="<?php echo esc_attr($primary_keyword); ?>" class="widefat">
            </p>
            <p>
                <label for="ai_secondary_keywords"><strong>Secondary Keywords (comma separated):</strong></label><br>
                <input type="text" id="ai_secondary_keywords" name="ai_secondary_keywords" value="<?php echo esc_attr($secondary_keywords); ?>" class="widefat">
            </p>
            <p>
                <label for="ai_category"><strong>Category (ID or Name):</strong></label><br>
                <input type="text" id="ai_category" name="ai_category" value="<?php echo esc_attr($category); ?>" class="widefat">
            </p>
            <p>
                <label for="ai_generation_status"><strong>Generation Status:</strong></label><br>
                <select id="ai_generation_status" name="ai_generation_status" class="widefat">
                    <option value="pending" <?php selected($status, 'pending'); ?>>Pending</option>
                    <option value="processing" <?php selected($status, 'processing'); ?>>Processing</option>
                    <option value="completed" <?php selected($status, 'completed'); ?>>Completed</option>
                    <option value="failed" <?php selected($status, 'failed'); ?>>Failed</option>
                </select>
            </p>
            <?php if ($post_id): ?>
                <p>
                    <strong>Generated Post ID:</strong> <?php echo esc_html($post_id); ?>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    public function save_topic_meta($post_id) {
        if (!isset($_POST['ai_topic_meta_nonce']) || !wp_verify_nonce($_POST['ai_topic_meta_nonce'], 'ai_topic_meta_save')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $fields = array(
            'ai_primary_keyword'     => '_ai_primary_keyword',
            'ai_secondary_keywords'  => '_ai_secondary_keywords',
            'ai_category'            => '_ai_category',
            'ai_generation_status'    => '_ai_generation_status',
        );

        foreach ($fields as $key => $meta_key) {
            if (isset($_POST[$key])) {
                update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$key]));
            }
        }
    }

    /**
     * Get topics by status.
     */
    public function get_topics_by_status($status = 'pending') {
        $args = array(
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'     => '_ai_generation_status',
                    'value'   => $status,
                    'compare' => '=',
                ),
            ),
        );

        return get_posts($args);
    }

    public function activate() {
        $this->register_post_type();
        flush_rewrite_rules();
    }
}
