<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AI_Autoblogger_Job_Manager
 * 
 * Handles the queue of topics, background execution via WP-Cron, 
 * and concurrency locking.
 */
class AI_Autoblogger_Job_Manager {
    private static $instance = null;
    private $lock_transient = 'ai_autoblogger_processing_lock';
    private $cron_hook = 'ai_autoblogger_cron_event';

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action($this->cron_hook, array($this, 'process_queue'));
    }

    /**
     * Initializes the cron schedule based on settings.
     */
    public function schedule_cron() {
        $settings = AI_Autoblogger_Settings::get_instance()->get_group('automation');
        
        // Fix: Use null coalescing operator to handle missing settings
        if (($settings['enabled'] ?? 'no') !== 'yes') {
            wp_clear_scheduled_hook($this->cron_hook);
            return;
        }

        if (!wp_next_scheduled($this->cron_hook)) {
            $recurrence = $this->get_recurrence_interval($settings['frequency'] ?? 'daily');
            wp_schedule_event(time(), $recurrence, $this->cron_hook);
        }
    }

    /**
     * The main worker that processes pending topics.
     */
    public function process_queue() {
        // 1. Prevent concurrent executions (Locking)
        if (get_transient($this->lock_transient)) {
            return; 
        }
        set_transient($this->lock_transient, true, 15 * MINUTE_IN_SECONDS);

        try {
            $settings = AI_Autoblogger_Settings::get_instance()->get_group('automation');
            $limit = absint($settings['articles_per_run'] ?? 1);
            
            $topic_manager = AI_Autoblogger_Topic_Manager::get_instance();
            $pending_topics = $topic_manager->get_topics_by_status('pending');

            if (empty($pending_topics)) {
                delete_transient($this->lock_transient);
                return;
            }

            $processed_count = 0;
            foreach ($pending_topics as $topic) {
                if ($processed_count >= $limit) break;

                $this->process_topic($topic->ID);
                $processed_count++;
            }
        } catch (Exception $e) {
            // Log critical failure
            error_log('AI Autoblogger Job Error: ' . $e->getMessage());
        }

        delete_transient($this->lock_transient);
    }

    /**
     * Logic for processing a single topic.
     */
    private function process_topic($topic_id) {
        return $this->process_single_topic_now($topic_id);
    }

    /**
     * Public method to process a specific topic immediately.
     */
    public function process_single_topic_now($topic_id) {
        $logger = AI_Autoblogger_Logger::get_instance();
        $topic = get_post($topic_id);
        if (!$topic) return 'Topic not found.';
        
        $topic_title = $topic->post_title;

        // Update status to processing
        update_post_meta($topic_id, '_ai_generation_status', 'processing');
        $logger->log('info', "Manual generation triggered for topic: {$topic_title}");

        $generator = AI_Autoblogger_Article_Generator::get_instance();
        $post_manager = AI_Autoblogger_Post_Manager::get_instance();

        // Step 1: Generate
        $result = $generator->generate($topic_id);

        if (!$result['success']) {
            update_post_meta($topic_id, '_ai_generation_status', 'failed');
            $logger->log('error', "Generation failed for {$topic_title}: {$result['error']}");
            return $result['error'];
        }

        // Step 2: Create Post
        $post_id = $post_manager->create_post($result['data'], $topic_id);

        if (is_wp_error($post_id)) {
            update_post_meta($topic_id, '_ai_generation_status', 'failed');
            $logger->log('error', "Post creation failed for {$topic_title}: " . $post_id->get_error_message());
            return $post_id->get_error_message();
        }

        // Step 3: Mark Completed
        update_post_meta($topic_id, '_ai_generation_status', 'completed');
        $logger->log('success', "Successfully generated and created post ID {$post_id} for topic: {$topic_title}");
        
        return true;
    }

    private function get_recurrence_interval($frequency) {
        switch ($frequency) {
            case 'hourly': return 'hourly';
            case 'weekly': return 'weekly';
            case 'daily':
            default: return 'daily';
        }
    }
}
