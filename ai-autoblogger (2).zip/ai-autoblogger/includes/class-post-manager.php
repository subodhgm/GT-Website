<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AI_Autoblogger_Post_Manager
 * 
 * Handles the creation and update of native WordPress posts from generated AI content.
 */
class AI_Autoblogger_Post_Manager {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Creates a WordPress post from the provided AI content data.
     * 
     * @param array $content_data The structured data returned by the ArticleGenerator.
     * @param int $topic_id The ID of the ai_topic used to generate this content.
     * @return int|WP_Error Returns the new post ID on success, or WP_Error on failure.
     */
    public function create_post(array $content_data, int $topic_id) {
        $settings = AI_Autoblogger_Settings::get_instance()->get_group('general');
        $post_status = $settings['post_status'] ?? 'draft';

        // 1. Prepare the post object
        $post_args = array(
            'post_title'   => sanitize_text_field($content_data['title']),
            'post_content' => wp_kses_post($content_data['content']),
            'post_excerpt' => sanitize_text_field($content_data['excerpt']),
            'post_name'    => sanitize_title($content_data['slug']),
            'post_status'  => $post_status,
            'post_author'  => get_current_user_id() ?: 1,
            'post_type'    => 'post',
        );

        // 2. Insert the post
        $post_id = wp_insert_post($post_args);

        if (is_wp_error($post_id)) {
            return $post_id;
        }

        // 3. Handle Tags
        if (!empty($content_data['tags']) && is_array($content_data['tags'])) {
            wp_set_post_tags($post_id, array_map('sanitize_text_field', $content_data['tags']), false);
        }

        // 4. Handle Category
        $category_val = get_post_meta($topic_id, '_ai_category', true);
        if (!empty($category_val)) {
            $this->assign_category($post_id, $category_val);
        }

        // 5. Save custom AI Metadata for SEO/Reference
        update_post_meta($post_id, '_ai_generated_meta_title', sanitize_text_field($content_data['meta_title'] ?? ''));
        update_post_meta($post_id, '_ai_generated_meta_desc', sanitize_text_field($content_data['meta_description'] ?? ''));
        update_post_meta($post_id, '_ai_focus_keyword', sanitize_text_field($content_data['focus_keyword'] ?? ''));
        update_post_meta($post_id, '_ai_word_count', absint($content_data['word_count'] ?? 0));

        // 6. Link the topic to the post
        update_post_meta($topic_id, '_ai_generated_post_id', $post_id);

        return $post_id;
    }

    /**
     * Assigns a category to the post, handling both IDs and names.
     */
    private function assign_category($post_id, $category_val) {
        if (is_numeric($category_val)) {
            wp_set_post_categories($post_id, array(absint($category_val)));
        } else {
            // Search for category by name
            $category = get_term_by('name', sanitize_text_field($category_val), 'category');
            if ($category) {
                wp_set_post_categories($post_id, array($category->term_id));
            } else {
                // Create the category if it doesn't exist
                $term = wp_insert_term(sanitize_text_field($category_val), 'category');
                if (!is_wp_error($term)) {
                    wp_set_post_categories($post_id, array($term['term_id']));
                }
            }
        }
    }
}
