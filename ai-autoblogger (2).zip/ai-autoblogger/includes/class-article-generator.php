<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AI_Autoblogger_Article_Generator
 * 
 * The core engine responsible for prompt building, calling providers, 
 * and validating the resulting content.
 */
class AI_Autoblogger_Article_Generator {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Main entry point to generate an article from a topic.
     * 
     * @param int $topic_id The ID of the ai_topic post.
     * @return array Result containing success status, the generated data, or error.
     */
    public function generate(int $topic_id) {
        $topic = get_post($topic_id);
        if (!$topic) {
            return array('success' => false, 'error' => 'Topic not found.');
        }

        // 1. Build the prompt
        $prompt = $this->build_prompt($topic);

        // 2. Resolve the active provider
        $provider = $this->get_active_provider();
        if (!$provider) {
            return array('success' => false, 'error' => 'No valid AI provider configured.');
        }

        // 3. Request generation
        $options = array(
            'timeout' => 120,
            'temperature' => 0.7,
            'max_tokens' => 4096,
        );

        $response = $provider->generate_text($prompt, $options);

        if (!$response->is_successful()) {
            return array('success' => false, 'error' => $response->error_message);
        }

        // 4. Validate and Process Content
        $content_data = $this->parse_and_validate_response($response->text);

        if (!$content_data['success']) {
            // Fallback: If JSON failed, try to treat as raw text for basic articles
            $content_data = $this->handle_fallback_content($response->text, $topic);
        }

        // 5. Validate Word Count
        $word_count = str_word_count(strip_tags($content_data['data']['content']));
        $max_words = (int) AI_Autoblogger_Settings::get_instance()->get_group('content')['max_word_count'];

        if ($word_count > $max_words * 1.2) { // 20% leeway
            // In a full implementation, we would trigger a shortening step here.
            // For V1, we log a warning but allow it if the content is high quality.
            // We'll add a flag to the result.
            $content_data['word_count_warning'] = true;
        }

        $content_data['data']['word_count'] = $word_count;

        return $content_data;
    }

    /**
     * Builds a structured prompt for the AI.
     */
    private function build_prompt($topic) {
        $settings = AI_Autoblogger_Settings::get_instance()->get_group('content');
        
        $primary_kw = get_post_meta($topic->ID, '_ai_primary_keyword', true);
        $secondary_kws = get_post_meta($topic->ID, '_ai_secondary_keywords', true);
        $instructions = $settings['instructions'] ?? '';
        $language = $settings['language'] ?? 'English';
        $tone = $settings['tone'] ?? 'Professional';
        $type = $settings['article_type'] ?? 'Blog Article';
        $max_words = $settings['max_word_count'] ?? 2000;

        $prompt = "You are an expert content writer. Write a high-quality {$type} in {$language} with a {$tone} tone.\n\n";
        $prompt .= "Topic: {$topic->post_title}\n";
        $prompt .= "Primary Keyword: {$primary_kw}\n";
        $prompt .= "Secondary Keywords: {$secondary_kws}\n";
        $prompt .= "Constraint: The article must be approximately {$max_words} words.\n";
        if (!empty($instructions)) {
            $prompt .= "Additional Instructions: {$instructions}\n";
        }
        $prompt .= "\nIMPORTANT: You must return the response as a valid JSON object with the following keys:\n";
        $prompt .= "- title: A compelling headline\n";
        $prompt .= "- slug: A URL-friendly slug\n";
        $prompt .= "- excerpt: A brief summary (1-2 sentences)\n";
        $prompt .= "- content: The full article in HTML format (use h2, h3, p, ul, li tags). Do not include <html> or <body> tags.\n";
        $prompt .= "- meta_title: SEO title\n";
        $prompt .= "- meta_description: SEO description\n";
        $prompt .= "- focus_keyword: The primary keyword used\n";
        $prompt .= "- tags: An array of 3-5 relevant tags\n\n";
        $prompt .= "Return ONLY the JSON object. No preamble or markdown code blocks.";

        return $prompt;
    }

    /**
     * Parses AI response into the required structured data.
     */
    private function parse_and_validate_response($text) {
        $text = trim($text);

        // Find the first occurrence of '{' and last occurrence of '}'
        $start_pos = strpos($text, '{');
        $end_pos = strrpos($text, '}');

        if ($start_pos === false || $end_pos === false || $end_pos < $start_pos) {
            return array('success' => false, 'error' => 'No JSON object found in AI response.');
        }

        // Extract only the JSON part
        $json_text = substr($text, $start_pos, ($end_pos - $start_pos) + 1);
        $data = json_decode($json_text, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            return array('success' => false, 'error' => 'Malformed JSON response from AI.');
        }

        // Validate required keys
        $required = array('title', 'content', 'excerpt');
        foreach ($required as $key) {
            if (empty($data[$key])) {
                return array('success' => false, 'error' => "Missing required field: {$key}");
            }
        }

        return array('success' => true, 'data' => $data);
    }

    /**
     * Fallback for models that fail to output JSON.
     */
    private function handle_fallback_content($text, $topic) {
        return array(
            'success' => true,
            'data' => array(
                'title' => $topic->post_title,
                'slug' => sanitize_title($topic->post_title),
                'excerpt' => wp_trim_words($text, 30),
                'content' => wpautop($text),
                'meta_title' => $topic->post_title,
                'meta_description' => wp_trim_words($text, 20),
                'focus_keyword' => get_post_meta($topic->ID, '_ai_primary_keyword', true),
                'tags' => array('AI Generated'),
            )
        );
    }

    /**
     * Factory method to get the currently selected provider.
     */
    private function get_active_provider() {
        $general = AI_Autoblogger_Settings::get_instance()->get_group('general');
        $provider_slug = $general['ai_provider'] ?? 'gemini';

        switch ($provider_slug) {
            case 'gemini':
                return new Gemini_Provider();
            case 'ollama':
                return new Ollama_Provider();
            default:
                return null;
        }
    }
}
