<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Ollama_Provider
 * 
 * Implementation of AI_Provider_Interface for local Ollama API.
 */
class Ollama_Provider implements AI_Provider_Interface {
    private $endpoint;
    private $model;

    public function __construct() {
        $settings = AI_Autoblogger_Settings::get_instance()->get_group('provider_ollama');
        $this->endpoint = rtrim($settings['endpoint'] ?? 'http://127.0.0.1:11434', '/');
        $this->model = $settings['model'] ?? 'gemma3:latest';
    }

    public function generate_text(string $prompt, array $options = []): AI_Provider_Response {
        if (empty($this->endpoint)) {
            return new AI_Provider_Response(false, '', null, 'Ollama endpoint is missing.');
        }

        $url = $this->endpoint . '/api/generate';

        $body = array(
            'model'  => $this->model,
            'prompt' => $prompt,
            'stream' => false, // We want a single response, not a stream
            'options' => array(
                'temperature' => $options['temperature'] ?? 0.7,
                'num_predict' => $options['max_tokens'] ?? 4096,
            )
        );

        $response = wp_remote_post($url, array(
            'body'    => json_encode($body),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => $options['timeout'] ?? 120, // Local models can be slower
        ));

        if (is_wp_error($response)) {
            return new AI_Provider_Response(false, '', null, "Could not connect to Ollama: " . $response->get_error_message());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body_content = wp_remote_retrieve_body($response);
        $data = json_decode($body_content, true);

        if ($status_code !== 200) {
            $error_msg = $data['error'] ?? 'Unknown Ollama API error';
            return new AI_Provider_Response(false, '', $body_content, "Ollama API Error ($status_code): $error_msg");
        }

        if (!isset($data['response'])) {
            return new AI_Provider_Response(false, '', $body_content, 'Ollama returned an unexpected response format.');
        }

        $text = $data['response'];
        
        return new AI_Provider_Response(
            true, 
            $text, 
            $body_content, 
            '', 
            str_word_count(strip_tags($text))
        );
    }

    public function test_connection(): bool {
        // We call the /api/tags endpoint to see if Ollama is alive and reachable
        // This is faster than generating text.
        $url = $this->endpoint . '/api/tags';
        
        $response = wp_remote_get($url, array('timeout' => 10));

        if (is_wp_error($response)) {
            return false;
        }

        return wp_remote_retrieve_response_code($response) === 200;
    }

    public function get_available_models(): array {
        $url = $this->endpoint . '/api/tags';
        $response = wp_remote_get($url, array('timeout' => 10));

        if (is_wp_error($response)) {
            return array();
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!isset($data['models'])) {
            return array();
        }

        return array_map(function($model) {
            return $model['name'];
        }, $data['models']);
    }
}
