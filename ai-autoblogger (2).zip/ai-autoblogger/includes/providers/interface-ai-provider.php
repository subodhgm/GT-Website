<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Interface AI_Provider_Interface
 * 
 * Defines the contract that all AI providers must follow to ensure 
 * the ArticleGenerator remains independent of the specific AI service.
 */
interface AI_Provider_Interface {
    
    /**
     * Generates a response based on the provided prompt and options.
     * 
     * @param string $prompt The full prompt sent to the AI.
     * @param array $options Additional options (e.g., temperature, max_tokens).
     * @return AI_Provider_Response Returns a standardized response object.
     * @throws Exception If the API request fails.
     */
    public function generate_text(string $prompt, array $options = []): AI_Provider_Response;

    /**
     * Tests the connection to the AI service.
     * 
     * @return bool True if connected, false otherwise.
     */
    public function test_connection(): bool;

    /**
     * Retrieves a list of available models from the provider if supported.
     * 
     * @return array List of model names/identifiers.
     */
    public function get_available_models(): array;
}

/**
 * Class AI_Provider_Response
 * 
 * A data-transfer object to standardize AI responses across different providers.
 */
class AI_Provider_Response {
    public $success;
    public $text;
    public $raw_response;
    public $error_message;
    public $word_count;

    public function __construct(bool $success, string $text = '', $raw_response = null, string $error_message = '', int $word_count = 0) {
        $this->success = $success;
        $this->text = $text;
        $this->raw_response = $raw_response;
        $this->error_message = $error_message;
        $this->word_count = $word_count;
    }

    public function is_successful(): bool {
        return $this->success;
    }
}
