<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Gemini_Provider
 * 
 * Implementation of AI_Provider_Interface for Google Gemini API.
 */
class Gemini_Provider implements AI_Provider_Interface {
    private $api_key;
    private $model;
    private $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/';

    public function __construct() {
        $settings = AI_Autoblogger_Settings::get_instance()->get_group('provider_gemini');
        $this->api_key = $settings['api_key'] ?? '';
        $this->model = $settings['model'] ?? 'gemini-1.5-pro';
    }

    public function generate_text(string $prompt, array $options = []): AI_Provider_Response {
        if (empty($this->api_key)) {
            return new AI_Provider_Response(false, '', null, 'Gemini API key is missing.');
        }

        $url = sprintf('%s%s:generateContent?key=%s', $this->endpoint, $this->model, $this->api_key);

        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt)
                    )
                )
            ),
            'generationConfig' => array(
                'temperature' => $options['temperature'] ?? 0.7,
                'maxOutputTokens' => $options['max_tokens'] ?? 4096,
            )
        );

        $response = wp_remote_post($url, array(
            'body'    => json_encode($body),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => $options['timeout'] ?? 60,
        ));

        if (is_wp_error($response)) {
            return new AI_Provider_Response(false, '', null, $response->get_error_message());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body_content = wp_remote_retrieve_body($response);
        $data = json_decode($body_content, true);

        if ($status_code !== 200) {
            $error_msg = $data['error']['message'] ?? 'Unknown Gemini API error';
            return new AI_Provider_Response(false, '', $body_content, "Gemini API Error ($status_code): $error_msg");
        }

        // Gemini response structure: candidates[0].content.parts[0].text
        if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            return new AI_Provider_Response(false, '', $body_content, 'Gemini returned an unexpected response format.');
        }

        $text = $data['candidates'][0]['content']['parts'][0]['text'];
        
        return new AI_Provider_Response(
            true, 
            $text, 
            $body_content, 
            '', 
            str_word_count(strip_tags($text))
        );
    }

    public function test_connection(): bool {
        if (empty($this->api_key)) {
            return false;
        }

        // Use a very simple prompt to test connection
        $response = $this->generate_text('Ping', ['max_tokens' => 1]);
        return $response->is_successful();
    }

    public function get_available_models(): array {
        // Gemini models can be queried via API, but for V1 we'll return common defaults
        // to keep it lightweight, as API model listing requires different auth scopes.
        return array(
            'gemini-1.5-pro',
            'gemini-1.5-flash',
            'gemini-pro'
        );
    }
}
