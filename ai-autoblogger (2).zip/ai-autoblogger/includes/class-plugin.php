<?php
if (!defined('ABSPATH')) {
    exit;
}

class AI_Autoblogger_Plugin {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Private constructor for Singleton
    }

    public function init() {
        $this->load_dependencies();
        $this->init_hooks();
        
        // Explicitly instantiate core managers to trigger their hooks
        AI_Autoblogger_Admin::get_instance();
        AI_Autoblogger_Topic_Manager::get_instance();
    }

    private function load_dependencies() {
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-settings.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/providers/interface-ai-provider.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/providers/class-gemini-provider.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/providers/class-ollama-provider.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-topic-manager.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-article-generator.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-post-manager.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-job-manager.php';
        require_once AI_AUTOBLOGGER_PATH . 'includes/class-logger.php';
        require_once AI_AUTOBLOGGER_PATH . 'admin/class-admin.php';
    }

    private function init_hooks() {
        // Plugin activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Initialize Cron Job Manager
        add_action('admin_init', array($this, 'sync_cron_schedule'));
    }

    public function sync_cron_schedule() {
        AI_Autoblogger_Job_Manager::get_instance()->schedule_cron();
    }

    public function activate() {
        AI_Autoblogger_Settings::get_instance()->init_defaults();
        
        if (class_exists('AI_Autoblogger_Topic_Manager')) {
            AI_Autoblogger_Topic_Manager::get_instance()->activate();
        }
        
        AI_Autoblogger_Job_Manager::get_instance()->schedule_cron();
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
    }
}
