<?php
if (!defined('ABSPATH')) {
    exit;
}

class AI_Autoblogger_Settings {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function init_defaults() {
        $defaults = array(
            'general' => array(
                'ai_provider' => 'gemini',
                'post_status' => 'draft',
            ),
            'provider_gemini' => array(
                'api_key' => '',
                'model' => 'gemini-1.5-pro',
            ),
            'provider_ollama' => array(
                'endpoint' => 'http://127.0.0.1:11434',
                'model' => 'gemma3:latest',
            ),
            'content' => array(
                'max_word_count' => 2000,
                'language' => 'English',
                'tone' => 'Professional',
                'instructions' => '',
                'article_type' => 'Blog Article',
            ),
            'automation' => array(
                'enabled' => 'no',
                'frequency' => 'daily',
                'articles_per_run' => 1,
            ),
        );

        foreach ($defaults as $group => $values) {
            add_option("ai_autoblogger_{$group}", $values);
        }
    }

    public function register_settings() {
        $groups = array('general', 'provider_gemini', 'provider_ollama', 'content', 'automation');
        foreach ($groups as $group) {
            register_setting(
                'ai_autoblogger_options_group', 
                "ai_autoblogger_{$group}", 
                array(
                    'sanitize_callback' => array($this, 'sanitize_group_settings'),
                )
            );
        }
    }

    public function sanitize_group_settings($input) {
        if (!is_array($input)) {
            return $input;
        }
        
        $sanitized = array();
        foreach ($input as $key => $value) {
            $sanitized[$key] = sanitize_text_field($value);
        }
        return $sanitized;
    }

    public function get_group($group) {
        return get_option("ai_autoblogger_{$group}", array());
    }
}
